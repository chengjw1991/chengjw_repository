create view lzxxinfo as
select l.id,l.slh,l.qymc,l.yh,l.code,l.date,l.bz,d.name from lzxx as l inner join dwxx as d on l.code = d.code;
go

