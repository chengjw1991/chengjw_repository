CREATE VIEW dbo.userallinfo
AS
SELECT   dbo.userinfo.id, dbo.userinfo.username, dbo.userinfo.realname, dbo.userinfo.sex, dbo.dwxx.name AS dwname, 
                dbo.dwxx.code AS dwcode, dbo.bmxx.name AS bmname, dbo.bmxx.code AS bmcode, dbo.bmxx.id AS bmid, 
                dbo.userinfo.phone, dbo.userinfo.registdate, dbo.userinfo.delflag, dbo.userinfo.userid, dbo.userinfo.prifilephoto, 
                dbo.roles.name AS rolename
FROM      dbo.userinfo INNER JOIN
                dbo.dwxx ON dbo.userinfo.dwcode = dbo.dwxx.code INNER JOIN
                dbo.bmxx ON dbo.userinfo.departmentid = dbo.bmxx.id INNER JOIN
                dbo.userRoles ON dbo.userinfo.id = dbo.userRoles.uid INNER JOIN
                dbo.roles ON dbo.userRoles.rid = dbo.roles.id
go

declare @MS_DiagramPane_
Begin
    DesignProperties = = N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
exec sp_addextendedproperty 'MS_DiagramPane1', @MS_DiagramPane_, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @___Begin_PaneConfigurations____         NumPanes = 4
=      Begin PaneConfiguration = 0
exec sp_addextendedproperty '
    Begin
        PaneConfigurations =
            ', @___Begin_PaneConfigurations____, ' SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________Configuration_____H__________________________      Begin PaneConfiguration = 1
=      End
exec sp_addextendedproperty '         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
', @_________Configuration_____H__________________________, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________NumPanes_____      End
=         Configuration = "(H (1 [50] 4 [25] 3))"
exec sp_addextendedproperty '         NumPanes = 3
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @______Begin_PaneConfiguration_____         Configuration = "(H (1 [50] 2 [25] 3))"
=         NumPanes = 3
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 2
', @______Begin_PaneConfiguration_____, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @______End_         NumPanes = 3
=      Begin PaneConfiguration = 3
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________Configuration_____H_____________________      Begin PaneConfiguration = 4
=      End
exec sp_addextendedproperty '         Configuration = "(H (4 [30] 2 [40] 3))"
', @_________Configuration_____H_____________________, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________NumPanes_____      End
=         Configuration = "(H (1 [56] 3))"
exec sp_addextendedproperty '         NumPanes = 2
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @______Begin_PaneConfiguration_____         Configuration = "(H (2 [66] 3))"
=         NumPanes = 2
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 5
', @______Begin_PaneConfiguration_____, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @______End_         NumPanes = 2
=      Begin PaneConfiguration = 6
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________Configuration_____H______________      Begin PaneConfiguration = 7
=      End
exec sp_addextendedproperty '         Configuration = "(H (4 [50] 3))"
', @_________Configuration_____H______________, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________NumPanes_____      End
=         Configuration = "(V (3))"
exec sp_addextendedproperty '         NumPanes = 1
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @______Begin_PaneConfiguration_____         Configuration = "(H (1[56] 4[18] 2) )"
=         NumPanes = 3
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 8
', @______Begin_PaneConfiguration_____, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @______End_         NumPanes = 2
=      Begin PaneConfiguration = 9
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________Configuration_____H______________      Begin PaneConfiguration = 10
=      End
exec sp_addextendedproperty '         Configuration = "(H (1 [75] 4))"
', @_________Configuration_____H______________, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________NumPanes_____      End
=         Configuration = "(H (1[66] 2) )"
exec sp_addextendedproperty '         NumPanes = 2
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @______Begin_PaneConfiguration______         Configuration = "(H (4 [60] 2))"
=         NumPanes = 2
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 11
', @______Begin_PaneConfiguration______, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @______End_         NumPanes = 1
=      Begin PaneConfiguration = 12
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________Configuration_____H________      Begin PaneConfiguration = 13
=      End
exec sp_addextendedproperty '         Configuration = "(H (1) )"
', @_________Configuration_____H________, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________NumPanes_____      End
=         Configuration = "(V (4))"
exec sp_addextendedproperty '         NumPanes = 1
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @______Begin_PaneConfiguration______         Configuration = "(V (2))"
=         NumPanes = 1
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 14
', @______Begin_PaneConfiguration______, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @______End_   End
=      ActivePaneConfig = 0
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @___Begin_DiagramPane____         Top = 0
=      Begin Origin = 
exec sp_addextendedproperty '
        Begin
            DiagramPane =
                ', @___Begin_DiagramPane____, ' SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________Left_____      Begin Tables = 
=      End
exec sp_addextendedproperty '         Left = 0
', @_________Left_____, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________Begin_Table____userinfo__               Top = 6
=            Begin Extent = 
exec sp_addextendedproperty '
            Begin
                Table = "userinfo"
', @_________Begin_Table____userinfo__, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_______________Left______               Right = 206
=               Bottom = 146
exec sp_addextendedproperty '               Left = 38
', @_______________Left______, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @____________End_            TopColumn = 0
=            DisplayFlags = 280
exec sp_addextendedproperty '
            End ', @____________End_, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________End_            Begin Extent = 
=         Begin Table = "dwxx"
exec sp_addextendedproperty '
        End ', @_________End_, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_______________Top_____               Bottom = 146
=               Left = 244
exec sp_addextendedproperty '               Top = 6
', @_______________Top_____, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_______________Right_______            DisplayFlags = 280
=            End
exec sp_addextendedproperty '               Right = 386
', @_______________Right_______, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @____________TopColumn_____         Begin Table = "bmxx"
=         End
exec sp_addextendedproperty '            TopColumn = 0
', @____________TopColumn_____, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @____________Begin_Extent____               Left = 38
=               Top = 150
exec sp_addextendedproperty '
        Begin
            Extent =
                ', @____________Begin_Extent____, ' SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_______________Bottom_______            End
=               Right = 180
exec sp_addextendedproperty '               Bottom = 290
', @_______________Bottom_______, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @____________DisplayFlags_______         End
=            TopColumn = 0
exec sp_addextendedproperty '            DisplayFlags = 280
', @____________DisplayFlags_______, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________Begin_Table____userRoles__               Top = 6
=            Begin Extent = 
exec sp_addextendedproperty '
            Begin
                Table = "userRoles"
', @_________Begin_Table____userRoles__, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_______________Left_______               Right = 566
=               Bottom = 127
exec sp_addextendedproperty '               Left = 424
', @_______________Left_______, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @____________End_            TopColumn = 0
=            DisplayFlags = 280
exec sp_addextendedproperty '
            End ', @____________End_, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________End_            Begin Extent = 
=         Begin Table = "roles"
exec sp_addextendedproperty '
        End ', @_________End_, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_______________Top_____               Bottom = 146
=               Left = 604
exec sp_addextendedproperty '               Top = 6
', @_______________Top_____, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_______________Right_______            DisplayFlags = 280
=            End
exec sp_addextendedproperty '               Right = 755
', @_______________Right_______, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @____________TopColumn_____      End
=         End
exec sp_addextendedproperty '            TopColumn = 0
', @____________TopColumn_____, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @___End_   End
=   Begin SQLPane = 
exec sp_addextendedproperty '
    End ', @___End_, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @___Begin_DataPane____      End
=      Begin ParameterDefaults = ""
exec sp_addextendedproperty '
    Begin
        DataPane =
            ', @___Begin_DataPane____, ' SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @______Begin_ColumnWidths_____         Width = 1500
=         Width = 284
exec sp_addextendedproperty '
        Begin
            ColumnWidths = 9
', @______Begin_ColumnWidths_____, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________Width________         Width = 1500
=         Width = 1500
exec sp_addextendedproperty '         Width = 1500
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________Width________         Width = 1500
=         Width = 1500
exec sp_addextendedproperty '         Width = 1500
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________Width________   End
=      End
exec sp_addextendedproperty '         Width = 1500
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @___Begin_CriteriaPane____         Column = 1440
=      Begin ColumnWidths = 11
exec sp_addextendedproperty '
            Begin
                CriteriaPane =
                    ', @___Begin_CriteriaPane____, ' SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

exec sp_addextendedproperty '         Alias = 900
',         Table = ', 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @MS_DiagramPane_ Output = 720
    = N'1170
exec sp_addextendedproperty 'MS_DiagramPane2', @MS_DiagramPane_, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________Append________         SortType = 1350
=         NewValue = 1170
exec sp_addextendedproperty '         Append = 1400
', @_________Append________, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________SortOrder________         Filter = 1350
=         GroupBy = 1350
exec sp_addextendedproperty '         SortOrder = 1410
', @_________SortOrder________, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_________Or________         Or = 1350
=         Or = 1350
exec sp_addextendedproperty '         Or = 1350
', @_________Or________, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @______End_ End
=   End
exec sp_addextendedproperty '
End
', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

declare @_ MS_DiagramPaneCount = nvarchar
exec sp_addextendedproperty '''', @_, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

exec sp_addextendedproperty '2', int, 'SCHEMA', 'dbo', 'VIEW', 'userallinfo'
go

