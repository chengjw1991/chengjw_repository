CREATE VIEW dbo.companyallinfo
AS
SELECT   c.id, s.kh, s.slr, s.slh, s.ywlx, s.slrq, c.slys, c.qymc, c.tyshxydm, c.zch, c.qylx, c.gxjg, c.ztzt, s.ewm, c.code, c.del, c.clrq, 
                s.zrdd, s.yfp, c.isborrow, c.slrbm, d.dwjc, sl.name AS slzt
FROM      dbo.companyinfo AS c INNER JOIN
                dbo.slxx AS s ON c.slh = s.slh INNER JOIN
                dbo.slzt AS sl ON s.slzt = sl.id INNER JOIN
                dbo.dwxx AS d ON c.code = d.code
go

declare @MS_DiagramPane_
Begin
    DesignProperties = = N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
exec sp_addextendedproperty 'MS_DiagramPane1', @MS_DiagramPane_, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @___Begin_PaneConfigurations____         NumPanes = 4
=      Begin PaneConfiguration = 0
exec sp_addextendedproperty '
    Begin
        PaneConfigurations =
            ', @___Begin_PaneConfigurations____, ' SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Configuration_____H__________________________      Begin PaneConfiguration = 1
=      End
exec sp_addextendedproperty '         Configuration = "(H (1[41] 4[20] 2[18] 3) )"
', @_________Configuration_____H__________________________, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________NumPanes_____      End
=         Configuration = "(H (1 [50] 4 [25] 3))"
exec sp_addextendedproperty '         NumPanes = 3
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @______Begin_PaneConfiguration_____         Configuration = "(H (1 [50] 2 [25] 3))"
=         NumPanes = 3
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 2
', @______Begin_PaneConfiguration_____, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @______End_         NumPanes = 3
=      Begin PaneConfiguration = 3
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Configuration_____H_____________________      Begin PaneConfiguration = 4
=      End
exec sp_addextendedproperty '         Configuration = "(H (4 [30] 2 [40] 3))"
', @_________Configuration_____H_____________________, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________NumPanes_____      End
=         Configuration = "(H (1 [56] 3))"
exec sp_addextendedproperty '         NumPanes = 2
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @______Begin_PaneConfiguration_____         Configuration = "(H (2 [66] 3))"
=         NumPanes = 2
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 5
', @______Begin_PaneConfiguration_____, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @______End_         NumPanes = 2
=      Begin PaneConfiguration = 6
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Configuration_____H______________      Begin PaneConfiguration = 7
=      End
exec sp_addextendedproperty '         Configuration = "(H (4 [50] 3))"
', @_________Configuration_____H______________, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________NumPanes_____      End
=         Configuration = "(V (3))"
exec sp_addextendedproperty '         NumPanes = 1
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @______Begin_PaneConfiguration_____         Configuration = "(H (1[56] 4[18] 2) )"
=         NumPanes = 3
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 8
', @______Begin_PaneConfiguration_____, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @______End_         NumPanes = 2
=      Begin PaneConfiguration = 9
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Configuration_____H______________      Begin PaneConfiguration = 10
=      End
exec sp_addextendedproperty '         Configuration = "(H (1 [75] 4))"
', @_________Configuration_____H______________, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________NumPanes_____      End
=         Configuration = "(H (1[66] 2) )"
exec sp_addextendedproperty '         NumPanes = 2
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @______Begin_PaneConfiguration______         Configuration = "(H (4 [60] 2))"
=         NumPanes = 2
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 11
', @______Begin_PaneConfiguration______, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @______End_         NumPanes = 1
=      Begin PaneConfiguration = 12
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Configuration_____H________      Begin PaneConfiguration = 13
=      End
exec sp_addextendedproperty '         Configuration = "(H (1) )"
', @_________Configuration_____H________, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________NumPanes_____      End
=         Configuration = "(V (4))"
exec sp_addextendedproperty '         NumPanes = 1
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @______Begin_PaneConfiguration______         Configuration = "(V (2))"
=         NumPanes = 1
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 14
', @______Begin_PaneConfiguration______, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @______End_   End
=      ActivePaneConfig = 0
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @___Begin_DiagramPane____         Top = 0
=      Begin Origin = 
exec sp_addextendedproperty '
        Begin
            DiagramPane =
                ', @___Begin_DiagramPane____, ' SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Left_____      Begin Tables = 
=      End
exec sp_addextendedproperty '         Left = 0
', @_________Left_____, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Begin_Table____c__               Top = 6
=            Begin Extent = 
exec sp_addextendedproperty '
            Begin
                Table = "c"
', @_________Begin_Table____c__, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_______________Left______               Right = 181
=               Bottom = 146
exec sp_addextendedproperty '               Left = 38
', @_______________Left______, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @____________End_            TopColumn = 9
=            DisplayFlags = 280
exec sp_addextendedproperty '
            End ', @____________End_, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________End_            Begin Extent = 
=         Begin Table = "s"
exec sp_addextendedproperty '
        End ', @_________End_, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_______________Top_____               Bottom = 146
=               Left = 219
exec sp_addextendedproperty '               Top = 6
', @_______________Top_____, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_______________Right_______            DisplayFlags = 280
=            End
exec sp_addextendedproperty '               Right = 361
', @_______________Right_______, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @____________TopColumn_____         Begin Table = "sl"
=         End
exec sp_addextendedproperty '            TopColumn = 0
', @____________TopColumn_____, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @____________Begin_Extent____               Left = 399
=               Top = 6
exec sp_addextendedproperty '
        Begin
            Extent =
                ', @____________Begin_Extent____, ' SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_______________Bottom_______            End
=               Right = 541
exec sp_addextendedproperty '               Bottom = 127
', @_______________Bottom_______, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @____________DisplayFlags_______         End
=            TopColumn = 0
exec sp_addextendedproperty '            DisplayFlags = 280
', @____________DisplayFlags_______, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Begin_Table____d__               Top = 205
=            Begin Extent = 
exec sp_addextendedproperty '
            Begin
                Table = "d"
', @_________Begin_Table____d__, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_______________Left_______               Right = 414
=               Bottom = 345
exec sp_addextendedproperty '               Left = 272
', @_______________Left_______, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @____________End_            TopColumn = 0
=            DisplayFlags = 280
exec sp_addextendedproperty '
            End ', @____________End_, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________End_   End
=      End
exec sp_addextendedproperty '
        End ', @_________End_, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @___Begin_SQLPane____   Begin DataPane = 
=   End
exec sp_addextendedproperty '
        Begin
            SQLPane =
                ', @___Begin_SQLPane____, ' SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @______Begin_ParameterDefaults______      Begin ColumnWidths = 19
=      End
exec sp_addextendedproperty '
            Begin
                ParameterDefaults = ""
                                    ', @______Begin_ParameterDefaults______, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Width_______         Width = 1500
=         Width = 1500
exec sp_addextendedproperty '         Width = 284
', @_________Width_______, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Width________         Width = 1500
=         Width = 1500
exec sp_addextendedproperty '         Width = 1500
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Width________         Width = 1500
=         Width = 1500
exec sp_addextendedproperty '         Width = 1500
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Width________         Width = 1500
=         Width = 1500
exec sp_addextendedproperty '         Width = 1500
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Width________         Width = 1500
=         Width = 1500
exec sp_addextendedproperty '         Width = 1500
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Width________         Width = 1500
=         Width = 1500
exec sp_addextendedproperty '         Width = 1500
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Width________   End
=      End
exec sp_addextendedproperty '         Width = 1500
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @___Begin_CriteriaPane____         Column = 1440
=      Begin ColumnWidths = 11
exec sp_addextendedproperty '
                Begin
                    CriteriaPane =
                        ', @___Begin_CriteriaPane____, ' SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Alias_______         Output = 720
=         Table = 1170
exec sp_addextendedproperty '         Alias = 900
', @_________Alias_______, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Append____ MS_DiagramPane2 = nvarchar
exec sp_addextendedproperty '         Append = ''', @_________Append____, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @N______         SortType = 1350
=         NewValue = 1170
exec sp_addextendedproperty 'N''1400
', @N______, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________SortOrder________         Filter = 1350
=         GroupBy = 1350
exec sp_addextendedproperty '         SortOrder = 1410
', @_________SortOrder________, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_________Or________         Or = 1350
=         Or = 1350
exec sp_addextendedproperty '         Or = 1350
', @_________Or________, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @______End_ End
=   End
exec sp_addextendedproperty '
                End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

declare @_ MS_DiagramPaneCount = nvarchar
exec sp_addextendedproperty '''', @_, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

exec sp_addextendedproperty '2', int, 'SCHEMA', 'dbo', 'VIEW', 'companyallinfo'
go

