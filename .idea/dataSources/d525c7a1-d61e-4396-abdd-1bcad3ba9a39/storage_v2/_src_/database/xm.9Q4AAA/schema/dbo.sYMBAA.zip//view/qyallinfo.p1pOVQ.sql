  create view qyallinfo as select
  q.qyid,q.qymc,q.tyshxydm,q.zch,q.frdm,q.gxdw,q.qylx,d.name
  from qyinfo as q inner join dwxx as d on q.gxdw = d.code
  go

